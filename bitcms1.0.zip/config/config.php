<?
$mysql_host="localhost";
$mysql_user="root";
$mysql_pass="sjzott";
$mysql_dbname="bitcms";
?>