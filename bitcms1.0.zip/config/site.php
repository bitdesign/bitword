<?
$tpl_name="simple";
$tpl_root="view/template/simple";
$tpl_parent="view/template";
date_default_timezone_set('PRC');
$lan="cn";
