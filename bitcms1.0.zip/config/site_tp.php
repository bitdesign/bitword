<?='<?'."\n"?>
$tpl_name="<?=$tpl_name?>";
$tpl_root="view/template/<?=$tpl_name?>";
$tpl_parent="view/template";
date_default_timezone_set('PRC');
$lan="<?=$lan?>";
