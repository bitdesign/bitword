<?
$tcontents = array("en" => "Content","cn" => "内容管理");
$tblock = array("en" => "Category","cn" => "版块管理");
$tcontent = array("en" => "Content","cn" => "内容管理");
$tslider = array("en" => "Slider","cn" => "滑页图片");
$tpublish = array("en" => "Publish","cn" => "发布管理");
$tsetting = array("en" => "Setting","cn" => "系统管理");
$tdoset = array("en" => "Setting","cn" => "参数设置");
$ttheme = array("en" => "Theme","cn" => "主题管理");
$tlanguage = array("en" => "Language","cn" => "语言设置");
$tother = array("en" => "Other","cn" => "其他");
$tbackup = array("en" => "Backup","cn" => "数据备份");
$tclear = array("en" => "Clear all","cn" => "一键清理");
$trestore = array("en" => "Restore","cn" => "数据恢复");
$tlog = array("en" => "Syslog","cn" => "系统日志");
$tpassword = array("en" => "Password","cn" => "修改密码");


$tsuccess = array("en" => "Success","cn" => "操作成功");
$tfailed = array("en" => "Failed","cn" => "操作失败");
$tedit = array("en" => "Edit","cn" => "编辑内容");
$tcategory = array("en" => "Category","cn" => "分类");
$tselect = array("en" => "Select","cn" => "请选择");
$ttitle = array("en" => "Title","cn" => "标题");
$tkeyword = array("en" => "Keyword ","cn" => "关键字");
$tstatus = array("en" => "Status","cn" => "状态");
$tpublished = array("en" => "Published","cn" => "已发布");
$ttopublished = array("en" => "ToPublished","cn" => "待发布");
$tdraft = array("en" => "Draft","cn" => "草稿");
$ttext = array("en" => "Content","cn" => "文本内容");
$tsave = array("en" => "Save","cn" => "保存");
$tclose = array("en" => "Close","cn" => "关闭");
$tquery = array("en" => "Query","cn" => "查询");
$tadd = array("en" => "Add","cn" => "新增");

$tleft = array("en" => "Left","cn" => "左侧");
$tcenter = array("en" => "Center","cn" => "主页面");
$tright = array("en" => "Right","cn" => "右侧");

$toperation = array("en" => "Operation","cn" => "操作");
$tdelete = array("en" => "Delete","cn" => "删除");
$tmodify = array("en" => "Modify","cn" => "修改");

$tinputtm = array("en" => "Input Time","cn" => "录入时间");
$tedittm = array("en" => "Last Edit Time","cn" => "最后编辑时间");
$publishtm = array("en" => "Publish Time","cn" => "发布时间");



$tfirst = array("en" => "first","cn" => "首页");
$tlast = array("en" => "last","cn" => "尾页");
$tpre = array("en" => "pre","cn" => "上一页");
$tnext = array("en" => "next","cn" => "下一页");
$tskip = array("en" => "skiptp","cn" => "跳转到");
$tperpage = array("en" => "perpage","cn" => "每页显示");
$ttotal = array("en" => "total","cn" => "总记录数");


$timage = array("en" => "Image","cn" => "图标");
$tbrowse = array("en" => "Browse","cn" => "浏览");
$tupload = array("en" => "Upload","cn" => "上传");
$torder = array("en" => "Order","cn" => "序号");
$tname = array("en" => "Name","cn" => "名称");
$tposition = array("en" => "Position","cn" => "位置");
$tlink = array("en" => "Link","cn" => "超级链接");

$tincrepublish = array("en" => "Incremental Publish","cn" => "增量发布");
$ttopublish = array("en" => "Publish whole website","cn" => "整站重新发布");
$tpubpreview = array("en" => "Publish preview","cn" => "发布预览");

$tsitename = array("en" => "Sitename ","cn" => "站点名");
$tdescription = array("en" => "Description ","cn" => "站点描述");
$twebroot = array("en" => "Webroot","cn" => "站点根目录");
$taccstat = array("en" => "Access statistics code","cn" => "访问统计代码");

$tactive = array("en" => "Active","cn" => "启用");
$tok = array("en" => "OK","cn" => "确定");
$tpwdtips = array("en" => "Incorrect","cn" => "原密码输入错误!");
$tpwdori = array("en" => "Passwrod","cn" => "原密码");
$tpwdnew = array("en" => "New password","cn" => "新密码");
$tconfirm = array("en" => "Confirm","cn" => "确认");


$thomepage = array("en" => "HOMEPAGE","cn" => "新开首页");
$tlogout = array("en" => "LOGOUT","cn" => "退出登录");
$tlogerr = array("en" => "Username or password is wrong","cn" => "用户名或密码错误");

$trestoretips = array("en" => "Restore failed, please check the syslog","cn" => "恢复失败,具体细节请查看系统日志");



























/** site content **/
include "site.php"; 
$block_pos = array("-1" => "$tleft[$lan]","0" => "$tcenter[$lan]","1" => "$tright[$lan]");
$content_sts = array("-1" => "$tdraft[$lan]","0" => "$ttopublished[$lan]","1" => "$tpublished[$lan]");