<?
require_once('Controller.php');
require_once('model/Block.php');


class BlockController extends Controller{
	
	private  $block = null;
	
	function __construct(){
		parent::__construct();
		$this->block = new Block();
	}
	
	function listPage(){

		$arrayList = $this->block->getBlocks();
		require('view/admin/block.php');
	}
	
	
	function del(){
		$this->block->del($_POST["id"]);
		echo "true";
	}
	
	function save(){
		$this->block->save();
		echo "true";
	}
	
}
/*end*/