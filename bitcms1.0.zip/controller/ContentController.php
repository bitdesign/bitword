<?
require_once('Controller.php');
require_once('model/Content.php');
require_once('model/Block.php');

class ContentController extends Controller{
	
	private  $content = null;
	private  $block = null;
	
	function __construct(){
		parent::__construct();
		$this->content = new Content(); 
		$this->block = new Block(); 
	}
	
	
	function listPage(){
		
		$table = "(select a.*,b.block_name from content a left join block b on a.block_id=b.block_id order by edit_tm desc) mytable";
		$pager = parent::getPager($table,$this->content->db);
		$arrayList = $pager->getData();
		require('view/admin/content/list.php');
	}

	function del(){
		$this->content->del($_POST["id"]);
		echo "true";
	}

	function save(){
		$this->content->save();
		echo "true";
	}
	
	function editPage(){
		$blockList = $this->block->getArrayList("block");
		$obj = $this->content->getRecordById($_GET['id']);
		require('view/admin/content/add.php');
	}
}
/*end*/