<?
require_once('ui/Pager.php');

class Controller{

	function __construct(){
		session_start();
		if(!isset($_SESSION['loginuser']))
		{
			require('view/admin/login.php');
			exit();
		}
		
	}
	
	
	function getPager($table,$db){
		$pageNo = $_POST['skipValue'];
		$perPageCnt = $_POST['perPageCnt'];
		if(empty($pageNo)){
			$pageNo = 1;
		}
		if(empty($perPageCnt)){
			$perPageCnt = 10;
		}
		$pager = new Pager($table,$db,$pageNo,$perPageCnt);
		return $pager;
	}
}
/*end*/