<?
require_once('Controller.php');
require_once('lib/LogUtil.php');

class FileController extends Controller{
	
	function __construct(){
		parent::__construct();
	}	

	function upload(){
		
		$fileElementName = $_POST["name"];
		$filePath = $_POST["path"];
		$file = $_FILES[$fileElementName]['tmp_name'];
	    $dst_file = dirname(__FILE__).'/../'.$filePath.'/'.iconv('UTF-8','gb2312',$_FILES[$fileElementName]['name']);
	    
	    $error="";
	    $msg="";
		if(move_uploaded_file($file,$dst_file)){
			$msg = "true";
		}else{
			$msg = "false";
		}
		echo "{error: '" . $error . "',\nmsg: '" . $msg . "'\n}";
	}
	
	
	function download(){
		$fileName = $_GET["filename"];
		$file = fopen($fileName,"r");
		Header("Content-type:application/octet-stream");
		Header("Accept-Ranges:bytes");
		Header("Accept-Length:".filesize($fileName));
		Header("Content-Disposition:attachment;filename=".$fileName);
		echo fread($file,filesize($fileName));
		fclose($file);
	}
	
	
}