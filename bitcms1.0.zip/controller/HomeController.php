<?
class HomeController{
	
	function indexDyn($viewPage="index.php",$pubMod=true){
		
		
		require_once 'model/Slider.php';
		require_once 'model/Block.php';
		require_once('model/Content.php');
		
		$slider = new Slider();	
		$block = new Block();
		
		$sliderList = $slider->getArrayList("slider");
		$blocks = $block->getBlocksWithContent(50);
		
		$paras = $block->db->row2col("siteparas","name","value");
		$logo = $paras["logo"];
		$keywords = $paras["keywords"];
		$title = $paras["name"];
		$description = $paras["description"];
		$webroot = $paras["webroot"];
		$accstat = $paras["accstat"];
		
		include "config/site.php";
		$logo = "$webroot/images/upload/$logo";
		
		if( strcmp($viewPage,"info.php") == 0){
			$content = new Content();	
			$obj = $content->getRecordById($_GET['id']);
			$tm = date("YmdHis",time());
			$content->db->exec("update content set sts='1' , pub_tm='$tm' where id=".$_GET['id']);
		}
		
		require("$tpl_root/$viewPage");
		
	}
	
	function index(){
		include "config/site.php";
		require("$tpl_root/index.html");
	}
	
	function info(){
		$this->indexDyn("info.php");
	}
}
/*end*/