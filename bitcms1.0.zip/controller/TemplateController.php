<?
require_once('Controller.php');
require_once('lib/DirUtil.php');
require_once('lib/ZipUtil.php');

class TemplateController extends Controller{
	
	function changeTpl(){
		
		require("config/site.php");		
			
		$tpl_name = $_POST["tplNm"];
		ob_start();
		require("config/site_tp.php");
		$content = ob_get_contents();
		ob_end_clean();
		$fp = fopen("config/site.php", "w");
		fwrite($fp, $content);
		fclose($fp);
		echo "true";
	}
	
	function listTpl(){
		$dir = new DirUtil();
		$tplList = $dir->listdir("view/template");
		require('view/admin/template.php');
	}
	
	
	function changeLan(){
		
		require("config/site.php");	
		
		$lan = $_POST["lanNm"];
		ob_start();
		require("config/site_tp.php");
		$content = ob_get_contents();
		ob_end_clean();
		$fp = fopen("config/site.php", "w");
		fwrite($fp, $content);
		fclose($fp);
		echo "true";
	}
	
	function listLan(){
		require('view/admin/language.php');
	}
	
	function unzip(){
		$zipfile = $_POST["zipfile"];
		$zip = new ZipUtil();
		$zipFile = dirname(__FILE__)."/../view/template/".$zipfile;
		$unzipRet = $zip->unzip($zipFile, false, false, true);
		if($unzipRet){
			echo "true";
		}else{
			echo "false";
		}
	}
}
/*end*/