DROP TABLE IF EXISTS `block`;
DROP TABLE IF EXISTS `content`;
DROP TABLE IF EXISTS `siteparas`;
DROP TABLE IF EXISTS `slider`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `block` (
  `block_id` int(11) NOT NULL auto_increment,
  `block_name` varchar(256) NOT NULL,
  `dsp_img` varchar(256) default NULL,
  `block_order` int(11) NOT NULL,
  `block_pos` int(11) NOT NULL default '1',
  PRIMARY KEY  (`block_id`),
  UNIQUE KEY `block_name` (`block_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE `content` (
  `id` int(11) NOT NULL auto_increment,
  `block_id` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `dsp_img` varchar(256) default NULL,
  `keyword` text NOT NULL,
  `content` text NOT NULL,
  `input_tm` varchar(32) NOT NULL,
  `edit_tm` varchar(32) NOT NULL,
  `pub_tm` varchar(32) NOT NULL,
  `top_tm` varchar(32) NOT NULL,
  `sts` varchar(4) NOT NULL,
  `usr_id` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE `siteparas` (
  `name` varchar(256) NOT NULL,
  `value` varchar(1024) NOT NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE `slider` (
  `img_src` varchar(512) NOT NULL,
  `img_url` varchar(512) NOT NULL,
  `img_order` int(2) NOT NULL,
  UNIQUE KEY `img_order` (`img_order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE `users` (
  `usr_id` int(11) NOT NULL auto_increment,
  `rol_id` int(11) default NULL,
  `usr_nm` varchar(32) NOT NULL,
  `usr_rnm` varchar(32) default NULL,
  `usr_sts` char(1) NOT NULL,
  `usr_email` varchar(64) default NULL,
  `usr_pwd` varchar(32) NOT NULL,
  `tm_stmp` varchar(32) default NULL,
  `info1` varchar(256) default NULL,
  `info2` varchar(256) default NULL,
  `info3` varchar(256) default NULL,
  PRIMARY KEY  (`usr_id`),
  UNIQUE KEY `usr_nm` (`usr_nm`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


INSERT INTO `siteparas` VALUES ('logo', 'logo.png');
INSERT INTO `siteparas` VALUES ('name', 'BitCMS');
INSERT INTO `siteparas` VALUES ('keywords', 'CMS');
INSERT INTO `siteparas` VALUES ('description', 'Input your website description');
INSERT INTO `siteparas` VALUES ('webroot', 'bitcms');
