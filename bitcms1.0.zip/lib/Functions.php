<?php
function btime($str){
	return date('Y-m-d H:i:s',strtotime($str));
}

function tarray($arr){
	return empty($arr)?array():$arr;
}


function formatjs($str){
	$str = str_replace('"','\"',$str);
	$str = str_replace('script','scr"+"ipt',$str);
	$str = '"'.$str.'"';
	return $str;
}