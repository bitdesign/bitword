<?php
class LogUtil {

	private $fp;
	function __construct($file_name, $mode="a") {
		$this->fp = fopen($file_name, $mode);
	}
	function info( $str ){
		$curTm = date("Y-m-d H:i:s",time());
		fwrite($this->fp, "[ $curTm ] $str \r\n");
	}
	function release() {
		if ($this->fp != null) {
			fclose($this->fp);
		}
	}
	function __destruct() {
		if ($this->fp != null) {
			fclose($this->fp);
		}
	}
}