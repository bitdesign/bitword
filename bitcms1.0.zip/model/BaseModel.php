<?php

require_once "lib/MySQL.php";

class BaseModel {

	public $db;

	function __construct() {
		include "config/config.php"; //no include_once, because only first new XXX() will include config.php
		$this->db = new MySQL($mysql_host,$mysql_user,$mysql_pass,$mysql_dbname);
	}

	public function getArrayList($table,$option="") {
		
		return $this->db->queryForArray($table,$option);
	
	}
	
	public function release(){
		
		$this->db->release();
	
	}
}

