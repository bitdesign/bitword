<?php

require_once('BaseModel.php');

class Block extends BaseModel{

	public function del($id) {
		$this->db->del("block","block_id=".$id);
		$this->db->del("content","block_id=".$id);
	}
	
	public function save() {
		
		$arr = array (
			'block_id',
			'block_name',
			'dsp_img',
			'block_order',
			'block_pos'
		);
		$this->db->postSave("block", $arr);
	
	}
	
	
	public function getBlocks() {
		
		$blocks = $this->db->queryForArray("block");
		return $blocks;
	}
	
	/* $maxNum the max num contents of every block*/
	public function getBlocksWithContent($maxNum) {
		
		$block_poss = $this->db->queryForArray("(select distinct block_pos as block_pos from block) tmp");
		
		$arr = array();
		foreach ($block_poss as $block_pos){
			$pos = $block_pos["block_pos"];
			$bloks = $this->getBlocksWithContentByBlockPos($pos,$maxNum);
			$arr[$pos] = $bloks;
		}
		return $arr;
	}
	
	public function getBlocksWithContentByBlockPos($block_pos=0,$maxNum=50) {
		
		$blocks = $this->db->queryForArray("block","where block_pos=$block_pos order by block_order");
		$arr = array();
		foreach ($blocks as $key=>$block){
			$contents = $this->db->queryForArrayLimit("(select id,block_id,title,dsp_img,left(content,400) as content from content where sts='1' order by pub_tm desc  limit 0,$maxNum) tmp"," where block_id=".$block["block_id"]);
			$blocks[$key]["contents"] = $contents;
		}
		return $blocks;
	}
}


