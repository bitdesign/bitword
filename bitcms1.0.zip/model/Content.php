<?php

require_once('BaseModel.php');
require_once('lib/LogUtil.php');

class Content extends BaseModel{
	
	public function del($id) {
		
		return $this->db->del("content","id=".$id);
	
	}
	
	public function getRecordById($id) {
		
		return $this->db->readRecord("content","id=".$id);
	}
	
	
	
	public function save() {
		
		$arr = array (
			'id',
			'block_id',
			'title',
			'keyword',
			'content',
			'sts',
			'dsp_img',
			'input_tm',
			'edit_tm'
		);
		
		include "config/site.php";
		$curTm = date("YmdHis",time());
		if(empty($_POST["id"])){
			$_POST["input_tm"] = $curTm;
		}
		
		$_POST["edit_tm"] = $curTm;
		
		$dsp_img = $this->getFirstImg($_POST["content"]);
//		$log = new LogUtil("log/ctx.log");
//		$log->info($dsp_img);
		$_POST["dsp_img"] = $dsp_img;
		$this->db->postSave("content", $arr);
	
	}
	
	
	public function getFirstImg($str) {
		$flag = "/images/upload/image/";
		$flagLen = strlen($flag);
		$fromIndex = strpos($str,$flag);
		if($fromIndex < 0 ) return "";
		$toIndex = strpos($str, "\"", $fromIndex)-1;
		if($toIndex < $fromIndex ) return "";
		return substr($str,$fromIndex,$toIndex-$fromIndex);
	}
}


