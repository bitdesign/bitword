<?php

require_once('BaseModel.php');
class Siteparas extends BaseModel{

	public function save() {

		$arr = array (
			'logo',
			'name',
			'keywords',
			'description',
			'webroot',
			'accstat'
		);
		return $this->db->postInsertPair("siteparas", $arr);
	}
	
	
	public function getParas() {

		return $this->db->row2col("siteparas","name","value");
	}

}

