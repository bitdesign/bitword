<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href="css/admin.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/ajaxfileupload.js"></script>
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/jquery.ext.js"></script>
<script type="text/javascript" src="js/bitclock.js"></script>

<? include "config/translate.php"; ?>
<? include "lib/functions.php"; ?>