<!DOCTYPE html">
<html>
	
	<head>
		<title></title>
		
		<? include "_include.php"; ?>
		<script language="javascript" type="text/javascript">
			
			function doBackup(){
				location.href = "Admin!backup";
			}
			
			function doClear(){
				
				if(confirm("<?=$tconfirm[$lan] ?>?")){
					doDelFile("all");
				}
			}
			
			function doDelFile(f){
				$.post("Admin!delBackupFile",{"filename":f},
					function(data){
						if(data=="true"){
							location.reload();
						}else{
							alert("<?=$tfailed[$lan] ?>");
						}
					},"html"
				);
			}
		</script>
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$tbackup[$lan] ?></strong></div>
			<div class="pageContent">
				<div style="float:left;padding:10px;width:100%;">
					<input type="button" class="large_btn" value=" <?=$tbackup[$lan] ?> " onclick="doBackup();"/>
					<input type="button" class="large_btn" value=" <?=$tclear[$lan] ?> " onclick="doClear();" />
				</div>
				<?foreach ($fileList as $f){?>
					<div style="float:left;padding:10px;">
					<a href="File!download&filename=backup/<?=$f?>"><?=$f?></a>
					<a onclick=doDelFile("backup/<?=$f?>")><font color="red">[<?=$tdelete[$lan]?>]</font></a>
					</div>
				<?}?>
			</div>
		</div>			
	</body>
	
</html>