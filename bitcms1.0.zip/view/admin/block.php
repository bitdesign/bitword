<!DOCTYPE html">
<html>
	<head>
		<title></title>
		<? include "_include.php"; ?>
		<script language="javascript">
			
			function del(id)
			{
				$.post("Block!del",{"id":id},
						function(data) {
							if(data == "true"){
								location.reload();
							}else{
								alert("<?=$tfailed[$lan]?>");
							}
						},"html"
				);
			}
			
			function save(block_id,block_name,dsp_img,block_order,block_pos)
			{
				$("#block_id").val(block_id);
				$("#block_name").val(block_name);
				$("#dsp_img").val(dsp_img);
				$("#txt").val(dsp_img);
				$("#echoimg").attr("src","images/upload/"+dsp_img);
				$("#block_order").val(block_order);
				$("#block_pos").val(block_pos);
			}
			
			
			$(function(){
				
				$("#myform").validate({
					rules: { 
						'block_order': {
							required: true,
							isnum : true
						},'block_name': {
							required: true
						},'block_pos': {
							required: true,
							isnum : true
						}
					},
					submitHandler:function() {
						$.post("Block!save",$('#myform').formSerialize(),
							function(data) {
								if(data=="true"){
									location.reload();
								}else{
									 alert(data);	
								}
							},"html"
						);
					}
					
				});
				
			});//function end
			
			function add()
			{
				$("#myform").submit();
			}
			
			
			function doUpload()
			{
				filename = $("#image").val();
				var idx = filename.lastIndexOf('\\');
				filename = filename.substring(idx+1);
				
				$("#dsp_img").val(filename);
					
				$.ajaxFileUpload
				({
					url:'File!upload',
					data:{'name':'image','path':'images/upload/'},
					type:'POST',
					secureuri:false,
					fileElementId:'image',
					dataType: 'json',
					success: function (data, status){
						$("#echoimg").attr("src","images/upload/"+filename);
					},
					error: function (data, status, e){
						alert(e);
					}
				})
				return false;
			}
			
			function setFileName(str){
				$("#txt").val(str);
			}
		</script>
		
		
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$tblock[$lan]?></strong></div>
			<div class="pageContent">
				<table class="myTable">
						
						<tr><td class="td1"><?=$timage[$lan]?></td><td width="35%">
							<input class="input_text" type="text"   id="txt" style="width:240px;" value=""/>
							<input class="input_btn"  type="button" value="<?=$tbrowse[$lan]?>" />
							<input class="input_file" type="file"   id="image" name="image"   onchange="setFileName(this.value)" />
							<input class="input_btn"  type="button" value="<?=$tupload[$lan]?>" onclick="return doUpload();"/>
						</td><td rowspan="3"><img style="width:200px;height:120px;background:#eee;" src="" id="echoimg"/></td></tr>
						
						
					<form id="myform" method="post" action="Block!save">
						<input type="hidden" name="dsp_img"  id="dsp_img"/>
						<input type="hidden" name="block_id" id="block_id"/>
						<tr><td class="td1"><?=$tname[$lan]?></td><td><input class="input_text" type="text" name="block_name" id="block_name"/></td></tr> 
						<tr><td class="td1"><?=$torder[$lan]?></td><td><input class="input_text" type="text" name="block_order" id="block_order"/></td></tr>
						<tr><td class="td1"><?=$tposition[$lan]?></td>
							<td>
								<input class="input_text" name="block_pos" id="block_pos"/>
							</td><td></td>
						</tr>
						<tr>
							<td colspan="2">
								<input type="button" name="btn" onclick="add()" class="large_btn" style="margin:0 0px 0 30px" value="<?=$tsave[$lan]?>" />
							</td><td ></td>
						</tr>
					</form>
				</table>
				
				
				<form method="post" action="Block!listPage">	
					<table class="myTable">
							<tr class="tbhead"><td style="padding-left:50px;"><?=$tname[$lan]?></td><td><?=$torder[$lan]?></td><td><?=$tposition[$lan]?></td><td><?=$toperation[$lan]?></td></tr>
							<?foreach ($arrayList as $row){?>
								<tr>
									<td style="padding-left:50px;"><?=$row["block_name"]?></td>
									<td><?=$row["block_order"]?></td>
									<td><?=$row["block_pos"]?></td>
									<td>
										<a href='#' onclick=del(<?=$row["block_id"]?>)><?=$tdelete[$lan]?></a>&nbsp;
										<a href='#' onclick=save(<?=$row["block_id"]?>,'<?=$row["block_name"]?>','<?=$row["dsp_img"]?>',<?=$row["block_order"]?>,<?=$row["block_pos"]?>)><?=$tmodify[$lan]?></a>
									</td>
								</tr>
							<?}?>
							
					</table>
				</form>
			</div>
		</div>
	</body>
	
</html>