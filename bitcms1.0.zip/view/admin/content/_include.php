<? include "view/admin/_include.php"; ?>
<? $ke_root = "tools/kindeditor-4.1.7/"; ?>
<link rel="stylesheet" href="<?=$ke_root?>themes/default/default.css" />
<script charset="utf-8" src="<?=$ke_root?>kindeditor-min.js"></script>
<script charset="utf-8" src="<?=$ke_root?>lang/zh_CN.js"></script>