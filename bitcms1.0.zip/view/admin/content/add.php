<!DOCTYPE html">
<html>
	<head>
		<title></title>
		<? include "_include.php"; ?>
		
		<script language="javascript" type="text/javascript">
			
			//KindEditor Setting
			KindEditor.ready(function(K) {
				var editor1 = K.create('textarea[id="content"]', {
					cssPath : "<?=$ke_root?>plugins/code/prettify.css",
					uploadJson : "<?=$ke_root?>php/upload_json.php",
					fileManagerJson : "<?=$ke_root?>php/file_manager_json.php",
					allowFileManager : true,
					allowImageUpload : true,
					allowImageRemote : false, 
					afterBlur: function(){this.sync();}
				});
			});
			
			
			$(function(){
				$("#myform").validate({ 
					rules: { 
						'title': { 
							required: true
						},
						'keyword': { 
							required: true
						}
				}}); 
			});
			
			function doSubmit(){
				
				$.post("Content!save",$('#myform').formSerialize(),
						function(data) {
							if(data == "true"){
								alert("<?=$tsuccess[$lan]?>");
								location.href = "Content!listPage#top";
							}else{
								alert("<?=$tfailed[$lan]?>");
							}
						},"html"
				);
			}
			
			function doClose()
			{
				location.href="Content!listPage#top";
			}
		</script>
		
		
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$tedit[$lan]?></strong></div>
			<div class="pageContent">
				<form id="myform">
					<input type="hidden" name="id" value="<?=$obj["id"]?>" id="id"/>
					<input type="hidden" name="input_tm" value="<?=$obj["input_tm"]?>" id="input_tm"/>
					<table class="myTable">
						<tr><th><?=$tcategory[$lan]?></th>
							<td>
								<select name="block_id">
									<option value=''><?=$tselect[$lan]?></option>
									<?
										foreach ($blockList as $row){
											echo "<option value='".$row["block_id"]."'".($obj["block_id"]==$row["block_id"]?" selected ":"").">".$row["block_name"]."</option>";
										}
									?>
								</select>
								
							</td>
						</tr>
						<tr><th><?=$ttitle[$lan]?></th><td><input type="text" name="title" value='<?=$obj["title"]?>'/></td></tr>
						<tr><th><?=$tkeyword[$lan]?></th><td><input type="text" name="keyword" value='<?=$obj["keyword"]?>'/></td></tr>
						<tr><th><?=$tstatus[$lan]?></th>
							<td>
								<select name="sts">
									<option value="0" <? if($obj["sts"]=="0") echo "selected" ?>><?=$ttopublished[$lan]?></option>
									<option value="-1" <? if($obj["sts"]=="-1") echo "selected" ?>><?=$tdraft[$lan]?></option>
								</select>
							</td>
						</tr>
						<tr><th style="vertical-align:text-top;"><?=$ttext[$lan]?></th><td><textarea id="content" name="content" style="width:675px;height:400px;"><?=$obj["content"]?></textarea></td></tr>
						<tr><th></th><td><input type="button" onclick="doSubmit();" class="small_btn" value="<?=$tsave[$lan]?>"/><input type="button" onclick="doClose()" class="small_btn" value="<?=$tclose[$lan]?>"/></td></tr>
					</table>
				</form>
			</div>
		</div>	
	</body>
	
</html>