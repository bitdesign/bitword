<!DOCTYPE html">
<html>
	<head>
		<? include "_include.php"; ?>
		
		<title><?=$tconsole[$lan]?></title>
		<script language="javascript" type="text/javascript">
			
			function iFrameHeight() { 
				var ifm= document.getElementById("iframepage"); 
				var subWeb = ifm.contentDocument; 
				if(ifm != null && subWeb != null) { 
					ifm.height = subWeb.body.scrollHeight; 
				} 
			}
			
			$(document).ready(function(){	
				$("#timebar").colck({
					lan:"<?=$lan?>"
				});
			});
		</script>
		
		
	</head>
	
	<body>
		<div class="all">	
			
			<div class="logo">
				<img src="images/console-logo.png" height="200" width="200"/>
			</div>
			
			<div class="bar">
				<div class="tips">Welcome, <?=$_SESSION['loginuser']["usr_nm"]?>! </div>
				<div class="tips">IP:<?=$_SERVER["REMOTE_ADDR"]?></div>
				<div class="tips" id="timebar"></div>
				<div class="tips" style="float:right;">
					<a href="Home!index" target="_blank"><?=$thomepage[$lan]?></a>
					<a href="Login!logout" target="_self"><?=$tlogout[$lan]?></a>
				</div>
				
				
			</div>
			
			<div class="main">
				<div class="menu">
					<ul>
						
		      	<li>
		      		<span><?=$tcontents[$lan]?></span>
		      		<ul>
		      			<li><a href="Block!listPage"   target="iframepage"><?=$tblock[$lan]?></a></li>
		         	<li><a href="Content!listPage"    target="iframepage"><?=$tcontent[$lan]?></a></li>
		         	<li><a href="Slider!slider"     target="iframepage"><?=$tslider[$lan]?></a></li>
		         	<li><a href="Admin!publishPage"    target="iframepage"><?=$tpublish[$lan]?></a></li>
		         </ul>	
		      	</li>
		      	<li>
		      		<span><?=$tsetting[$lan]?></span>
		      		<ul>
		         	<li><a href="Setting!settingPage"    target="iframepage"><?=$tdoset[$lan]?></a></li>
		         	<li><a href="Template!listTpl"   target="iframepage"><?=$ttheme[$lan]?></a></li>
		         	<li><a href="Template!listLan"   target="iframepage"><?=$tlanguage[$lan]?></a></li>
		         </ul>	
		      	</li>
		      	
		      	<li>
		      		<span><?=$tother[$lan]?></span>
		      		<ul>
		      			<li><a href="Admin!changePassWordPage"  target="iframepage"><?=$tpassword[$lan]?></a></li>
		         		<li><a href="Admin!backupPage"    		target="iframepage"><?=$tbackup[$lan]?></a></li>
		         		<li><a href="Admin!restorePage"   		target="iframepage"><?=$trestore[$lan]?></a></li>
		         		<li><a href="Admin!logPage"    			target="iframepage"><?=$tlog[$lan]?></a></li>
		         	
		         </ul>	
		      	</li>
		      	
		      </ul>
             
				</div>
				
				<div class="content">
					<iframe id="iframepage"  name="iframepage" src="Content!listPage" frameborder="0" onLoad="iFrameHeight()" scrolling="no" width="100%">
	        		</iframe>
				</div>
				
			</div>
			
		</div>
		
		<div class="footer">
			<p>Copyright <a href="#">BitCMS Admin</a>. All Rights Reserved.</p>
		</div>
		
	</body>
	
</html>