<!DOCTYPE html">
<html>
	<head>
		<title>Administrator console</title>
		<? include "_include.php"; ?>
		<script language="javascript" type="text/javascript">
			function doLogin(){
				$.post("Login!login",$('#myform').formSerialize(),
						function(data) {
							if(data == "true"){
								location="Admin!index";
							}else{
								alert('<?=$tlogerr[$lan]?>');
							}
						},"html"
				);
			}
			$(document).ready(function(){ 
				$(document).keydown(function(e){ 
					var curKey = e.which; 
					if(curKey == 13){ 
						$("#dosub").click(); 
						return false; 
					} 
				}); 
			}); 
		</script>
	</head>
	<body class="login">
		<div class="loginbox">
			<div style="width:100%;height:30px;background:rgb(32,69,98);">
				<h1 style="color:#fff; margin-left:20px;height:30px; line-height:30px;">Administrator</h1>
			</div>
			<div style="width:100%;">
			<form id="myform">
				<table style="width:220px;margin:15px auto;">
					<tr><td><input style="background:rgb(253,253,228) url(images/user.png) left center no-repeat; " type="text" name="usr_nm" value=""/></td></tr>
					<tr><td><input style="background:rgb(253,253,228) url(images/passwrod.png) center left no-repeat; " type="password" name="usr_pwd" value=""/></td></tr>
					<tr><td></td></tr>
					<tr><td><a class="loginbtn" id="dosub" onclick="doLogin();">Login</a></td></tr>
				</table>
			</form>
			</div>
		<div/>
	</body>
</html>