<!DOCTYPE html">
<html>
	<head>
		
		<title></title>
		<? include "_include.php"; ?>
		<script lanuage="javascript">
			
			$(function(){
				
				$("#myform").validate({
					rules: {
						'ori_usr_pwd': {
							required: true,
							remote : {
								type:"post",
				               	async:true,
				               	url:"Admin!checkOriPassWord"
							}
						},
						'usr_pwd': {
							required: true,
						},
						're_usr_pwd': {
							equalTo:'#usr_pwd'
						}
					},
					messages: {
						'ori_usr_pwd': {
							remote : "<?=$tpwdtips[$lan]?>" 
						}
					},
					submitHandler:function() {
						$.post("Admin!changePassWord",$('#myform').formSerialize(),
							function(data) {
								if(data=="true"){
									alert("<?=$tsuccess[$lan]?>");
								}else{
									alert(data);
								}
							},"html"
						);
					}
					
				});
				
			});//function end
			
			function doSubmit(){
				$("#myform").submit();
			}
			
		</script>
		
		
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$tpassword[$lan]?></strong></div>
			<div class="pageContent">
				<form id="myform" name="myform">
					<table class="myTable">
						<tr><td class="td1"><?=$tpwdori[$lan]?></td><td><input type="password" name="ori_usr_pwd"/></td></tr>
						<tr><td class="td1"><?=$tpwdnew[$lan]?></td><td><input type="password" name="usr_pwd" id="usr_pwd"/></td></tr>
						<tr><td class="td1"><?=$tconfirm[$lan]?></td><td><input type="password" name="re_usr_pwd"/></td></tr>
						<tr><td class="td1"></td>
							<td><input type="button" name="ok" class="mid_btn" value="<?=$tok[$lan]?>" onclick="doSubmit();"/>
					</table>
				</form>
			</div>
		</div>
	</body>
	
</html>