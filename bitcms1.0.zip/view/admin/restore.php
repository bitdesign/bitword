<!DOCTYPE html">
<html>
	
	<head>
		<title></title>
		
		<? include "_include.php"; ?>
		<script language="javascript" type="text/javascript">
			
			function restoreData(){
				
				var f = $("input[name='selbkfile']:checked").val();
				$.post("Admin!restore",{"selbkfile":f},
					function(data){
						if(data=="true"){
							alert("<?=$tsuccess[$lan] ?>");
							location.reload();
						}else{
							alert("<?=$trestoretips[$lan]?>");
						}
					},"html"
				);
			}
			
			function doUpload()
			{
				var localFilename = $("#bkfile").val();
				var idx = localFilename.lastIndexOf('\\');
				if(idx<0){
					idx = localFilename.lastIndexOf('/');
				}
				filename = localFilename.substring(idx+1);
				$.ajaxFileUpload({
					url:'File!upload',
					data:{'name':'bkfile','path':'backup'},
					type:'POST',
					secureuri:false,
					fileElementId:'bkfile',
					dataType: 'json',
					success: function (data, status){
						if(data.msg == "true"){
							location.reload();
						}
						else{
							alert(data.msg);
							return;
						}
					},
					error: function (data, status, e){
						alert(e);
					}
				});
			}
		</script>
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$trestore[$lan]?></strong></div>
			<div class="pageContent">	
				<table class="myTable">
					<tr>
						<td>
							<?=$tupload[$lan]?>&nbsp;&nbsp;<input type="file" name="bkfile" id="bkfile"/>
							<input type="button" onclick="doUpload();" class="mid_btn" value="<?=$tupload[$lan]?>"/>
							<input type="button" onclick="restoreData();" class="large_btn"  value="<?=$trestore[$lan]?>"/>
						</td>
					</tr>
				</table>
				<?foreach ($fileList as $f){?>
					<div style="float:left;padding:10px;">
						<?=$f?><input type="radio" name="selbkfile" value="<?=$f?>" style="vertical-align:middle;"/>
					</div>
				<?}?>	
			</div>
		</div>
	</body>
	
</html>