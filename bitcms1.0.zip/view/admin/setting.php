<!DOCTYPE html">
<html>
	
	<head>
		<title></title>
		<? include "_include.php"; ?>
		<script type="text/javascript" src="js/ajaxfileupload.js"></script>
		<script language="javascript" type="text/javascript">
			function doUpload()
			{
				filename = $("#image").val();
				var idx = filename.lastIndexOf('\\');
				filename = filename.substring(idx+1);
				
				$("#logo").val(filename);
					
				$.ajaxFileUpload
				({
					url:'File!upload',
					data:{'name':'image','path':'<?=$tpl_root?>/images'},
					type:'POST',
					secureuri:false,
					fileElementId:'image',
					dataType: 'json',
					success: function (data, status){
						$("#echoimg").attr("src","<?=$tpl_root?>/images/"+filename);
					},
					error: function (data, status, e){
						alert(e);
					}
				})
				return false;
			}
			
			function setFileName(str){
				$("#txt").val(str);
			}
			
		</script>
		
		
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$tdoset[$lan]?></strong></div>
			<div class="pageContent">
				<table class="myTable">
						
						<tr><td class="td1">LOGO</td><td width="35%">
							<input class="input_text" type="text"   id="txt" style="width:240px;" value="<?=$paras['logo']?>"/>
							<input class="input_btn"  type="button" value="<?=$tbrowse[$lan]?>" />
							<input class="input_file" type="file"   id="image" name="image"   onchange="setFileName(this.value)" />
							<input class="input_btn"  type="button" value="<?=$tupload[$lan]?>" onclick="return doUpload();"/>
						</td><td rowspan="3"><img style="width:300px;height:100px;background:#eee;" src="images/upload/<?=$paras['logo']?>" id="echoimg"/></td></td></tr>
						
						
					<form action="Setting!save" method="POST">
						<input class="input_text" type="hidden" id="logo" name="logo" value="<?=$paras['logo']?>"/>
						<tr><td class="td1"><?=$tsitename[$lan]?></td><td><input class="input_text" type="text" name="name" value="<?=$paras['name']?>"/></td></tr>
						<tr><td class="td1"><?=$tkeyword[$lan]?></td><td><input class="input_text" type="text" name="keywords" value="<?=$paras['keywords']?>"/></td></tr>
						<tr><td class="td1"><?=$tdescription[$lan]?></td><td><input class="input_text" type="text" name="description" value="<?=$paras['description']?>"/></td></tr>
						<tr><td class="td1"><?=$twebroot[$lan]?></td><td><input class="input_text" type="text" name="webroot" value="<?=$paras['webroot']?>"/></td></tr>
						<tr><td class="td1"><?=$taccstat[$lan]?></td><td><textarea style="width:350px;height:100px;" name="accstat"/><?=$paras['accstat']?></textarea></td></tr>
						<tr><td class="td1"></td><td><input type="submit" class="mid_btn" value="<?=$tsave[$lan]?>"/><?=$msg?></td><td></td></tr>
					</form>
				</table>
			</div>
		</div>
	</body>
	
</html>