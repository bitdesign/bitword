<!DOCTYPE html">
<html>
	
	<head>
		<title></title>
		<? include "_include.php"; ?>
		<script type="text/javascript" src="js/ajaxfileupload.js"></script>
		
		<style>
			a img{ padding:1px;}
			a.slider img{ border:3px solid #efefef;height:120px;width:348px; }
			a.slider:hover img{border:3px solid #999;}
		</style>
		
		<script language="javascript" type="text/javascript">
			
			function doUploadAndSave()
			{
				var localFilename = $("#image").val();
				var idx = localFilename.lastIndexOf('\\');
				filename = localFilename.substring(idx+1);
				$("#img_src").val(filename);
				$.ajaxFileUpload
				({
					url:'File!upload',
					data:{'name':'image','path':'images/upload'},
					type:'POST',
					secureuri:false,
					fileElementId:'image',
					dataType: 'json',
					success: function (data, status){
						if(data.msg == "true"){
							$("#myform").submit();
						}else{
							alert("<?=$tfailed[$lan]?>!");
						}
					},
					error: function (data, status, e){
						alert(e);
					}
				})
				
			}
			
			function setInfo(img_src,img_url,img_order,id){
					
				$("#img_src").val(img_src);
				$("#img_url").val(img_url);
				$("#img_order").val(img_order);
				$("#img_order").css("border","2px solid #f00");
			}
			
			function doDelete(){
					
				var img_order = $("#img_order").val();
				
				$.post("Slider!del",{"img_order":img_order},
							function(data) {
								if(data=="true"){
									location.reload();
								}else{
									 alert("<?=$tfailed[$lan]?>");	
								}
							},"html"
					);
			}
		</script>
		
		
		
		
	</head>
	
	<body>
		<div class="iframeBody">
			
			<div class="pageName"><strong><?=$tslider[$lan]?></strong></div>
		
			<div class="pageContent">
				<form action="Slider!save" method="POST" id="myform">
					<table class="myTable">
						<tr>
							<td>
								<?=$torder[$lan]?>&nbsp;&nbsp;<input type="text" name="img_order" id="img_order" value="1"/>&nbsp;&nbsp;&nbsp;&nbsp;
								<?=$tlink[$lan]?>&nbsp;&nbsp;<input type="text" name="img_url" id="img_url" value="#"/>&nbsp;&nbsp;&nbsp;&nbsp;
								<?=$timage[$lan]?>&nbsp;&nbsp;<input type="file" name="image" id="image"/><span>[696*240]</span>
								<input  type="hidden" name="img_src" id="img_src" value="1"/>
								<input type="button" class="small_btn" onclick="return doUploadAndSave();" value="<?=$tsave[$lan]?>"/>
								<input type="button" class="small_btn" onclick="return doDelete();" value="<?=$tdelete[$lan]?>"/>
							</td>
							
							
						</tr>
						
						<tr>
							<td>
							<?foreach ($sliderList as $row){?>
								<a class="slider" id="<?=$row["img_order"]?>" onclick="setInfo('<?=$row["img_src"]?>','<?=$row["img_url"]?>','<?=$row["img_order"]?>','<?=$row["img_order"]?>')"><img src="images/upload/<?=$row["img_src"]?>"/></a>
							<?}?>		
							</td>
						</tr>
					</table>
				</form>
			</div>
				
		</div>
	</body>
	
</html>