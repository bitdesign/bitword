<!DOCTYPE html">
<html>
	<head>
		<?include "_include.php";?>
		
		<script>
			$(document).ready(function(){	
					$("#slider").bitSlider({
						delay: 300,
						space: 18,
						right: 30,
						showNum: true,
						prenext: false
					});
			});
		</script>
	</head>
	
	<body>
		<div class="all">
			<?include "_header.php";?>
			
			<div class="content">
				<div class="content_left">
					<?
					foreach (tarray($blocks[1]) as $block){
					?>
						<div class="box">
							<div class="title">
		                		<strong><?=$block["block_name"]?></strong>
			                </div>
			                <div class="ctx">
			                		<?foreach ($block["contents"] as $content){?>
				                		<p><a href="<?=$tpl_root?>/static/<?=$content['id']?>.html"><?=$content["title"]?></a></p>
				                		<span><?=$content["content"]?><br/>
				                		<a href="<?=$tpl_root?>/static/<?=$content['id']?>.html">[more]</a>
				                		</span>
			                		<?}?>
			                </div>
						</div>
					<?
					}
					?>
				</div>
				
				<div class="content_right">
					<div class="slider" id="slider">
						<div><span>Simple</span></div>
						<div><span>Flexible</span></div>
						<div><span>Efficient</span></div>
						<?
		//					foreach ($sliderList as $row){
		//						echo "<div style='background:url(images/upload/".$row["img_src"].")'></div>";
		//					}
						?>	
					</div>
					<?
					foreach ( tarray($blocks[9]) as $block){
					?>
						<div class="box box1">
							<div class="title">
		                		<strong><?=$block["block_name"]?></strong>
			                </div>
			                <div class="ctx">
			                	<ul>
			                		<?foreach ($block["contents"] as $content){?>
				                		<li name=info>
				                		<?
				                			echo $content["title"].":".$content["content"];
				                		?>
				                		</li>
			                		<?}?>
				                </ul>
			                </div>
						</div>
					<?
					}
					?>
					
				</div>
			</div>
			<?include "_footer.php";?>
		</div>
	</body>
	
</html>