<!DOCTYPE html">
<html>
	<head>
		<head>
		
		<?include "_include.php";?>
		
	</head>
		<style>
		
			.ctxTime {
				color:#999898;
				text-align:center;
				margin:5px 0 10px 0;
			}
			.ctxInfo {
				font-size:12px;
				line-height:22px;
			}
			h3 {
				font-size:15px;
				color:#e62900;
				font-weight:700;
				text-align:center;
			}
		</style>
	</head>
	
	<body>
		<div class="all">
			<?include "_header.php";?>
			
			<div style="margin:40px;">
				
				<h3><?=$obj["title"]?></h3>
				<p class="ctxTime"><?=$obj["edit_tm"]?></p>
				<div class="ctxInfo">
				<?=$obj["content"]?>
				</div>
			</div>
			
			<?include "_footer.php";?>
		</div>
	</body>
	
</html>