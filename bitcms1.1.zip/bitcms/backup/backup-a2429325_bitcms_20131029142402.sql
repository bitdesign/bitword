delete from block;
INSERT INTO `block` VALUES   ( '35', '最新文章', '', '2', '1');
INSERT INTO `block` VALUES   ( '34', '与我联系', '', '3', '9');
INSERT INTO `block` VALUES   ( '37', '时人时事', '', '0', '8');

delete from content;
INSERT INTO `content` VALUES   ( '12', '35', '程序员为什么要写一个属于自己的产品（序）', '<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;技术人员，最宝贵的是生命。生命对每个人只有一次！这仅有的一次生命，应当怎样度过呢？每当回忆往事的时候，能够不为虚度年华而悔恨，不因碌碌无为而羞耻。在临死的时候，他能够说——我曾经也尝试过独立完成并演进一个自己的产品！', '感悟', '<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;技术人员，最宝贵的是生命。生命对每个人只有一次！这仅有的一次生命，应当怎样度过呢？每当回忆往事的时候，能够不为虚度年华而悔恨，不因碌碌无为而羞耻。在临死的时候，他能够说——我曾经也尝试过独立完成并演进一个自己的产品！\" 做了这么多年的开发，恍有万千感慨，总结一句心得，\" 技术为兵 产品为王\" ! &nbsp; &nbsp;&nbsp;
</p>', '20130821091119', '20130825000653', '20131024143941', '', '1', '');
INSERT INTO `content` VALUES   ( '15', '34', 'Email', 'bitdesign@163.com<br /', '联系方式', 'bitdesign@163.com<br />', '20130821092431', '20130821111048', '20131024143941', '', '1', '');
INSERT INTO `content` VALUES   ( '16', '34', '新浪微博', '<iframe frameborder=', '联系方式', '<iframe frameborder=\"0\" height=\"22\" src=\"http://widget.weibo.com/relationship/followbutton.php?width=200&height=22&uid=1848702430&style=5&btn=red&dpc=1\" style=\"width:64px;height:22px; vertical-align:middle;\" width=\"200\" >
</iframe>', '20130821094054', '20130821104613', '20131024143941', '', '1', '');
INSERT INTO `content` VALUES   ( '17', '35', '拨开云雾见晴天', '经过了最近一段时间的游弋，再次明确并坚定了自己的方向。忽然间心情一下子好了起来，精神一下抖擞了起来，态度更为积极了，向着既定路线前进，一条自己信服的路', '', '经过了最近一段时间的游弋，再次明确并坚定了自己的方向。忽然间心情一下子好了起来，精神一下抖擞了起来，态度更为积极了，向着既定路线前进，一条自己信服的路。', '20130827140208', '20130827151030', '20131024143941', '', '1', '');
INSERT INTO `content` VALUES   ( '21', '37', '伞哥其人', '伞哥可为精兵 可为学者 莫为将', '', '伞哥可为精兵 可为学者 莫为将帅', '20131009233505', '20131024143623', '20131024143942', '', '1', '');
INSERT INTO `content` VALUES   ( '19', '35', '网站产品之态', '如今Web发展已经有了一定的成熟度， 传统的网站式项目模式的利润越来越少， 但真正的快速有效的开发方式并未普及，对于多数团队来说已经变成鸡肋项目。无休止的的变更，不明确的设计和功能需求，被竞争到超低的开发费用，已经很少有人愿意做类似的项目了吧', '', '如今Web发展已经有了一定的成熟度， 传统的网站式项目模式的利润越来越少， 但真正的快速有效的开发方式并未普及，对于多数团队来说已经变成鸡肋项目。无休止的的变更，不明确的设计和功能需求，被竞争到超低的开发费用，已经很少有人愿意做类似的项目了吧。', '20131009140823', '20131009140823', '20131024143942', '', '1', '');
INSERT INTO `content` VALUES   ( '20', '35', '程序员转型管理的思考', '在天朝，程序员到了一定的年纪，迫于精力和薪酬上的压力不得不考虑转型为管理类人才，我目前正在这个阶段上。 刚开始的时候就想着脱离编码，转型研究项目管理， 后发现技术一点也不能丢，在现阶段，技术仍是我最主要的竞争力，还是要跟上技术的进步和发展。慢慢拓展业务水平，逐渐培养管理能力和技巧', '', '在天朝，程序员到了一定的年纪，迫于精力和薪酬上的压力不得不考虑转型为管理类人才，我目前正在这个阶段上。 刚开始的时候就想着脱离编码，转型研究项目管理， 后发现技术一点也不能丢，在现阶段，技术仍是我最主要的竞争力，还是要跟上技术的进步和发展。慢慢拓展业务水平，逐渐培养管理能力和技巧。', '20131009141458', '20131009141458', '20131024143942', '', '1', '');

delete from siteparas;
INSERT INTO `siteparas` VALUES   ( 'logo', 'home-logo.png');
INSERT INTO `siteparas` VALUES   ( 'name', '比特设计中文博客');
INSERT INTO `siteparas` VALUES   ( 'keywords', 'bitdesign 比特设计 中文博客');
INSERT INTO `siteparas` VALUES   ( 'description', '比特设计中文博客');
INSERT INTO `siteparas` VALUES   ( 'webroot', '');
INSERT INTO `siteparas` VALUES   ( 'accstat', '<script src=\"http://s96.cnzz.com/stat.php?id=5602675&web_id=5602675&show=pic\" language=\"JavaScript\"></script>');

delete from slider;

delete from users;
INSERT INTO `users` VALUES   ( '1', NULL, 'admin', NULL, '1', NULL, 'e941e5415b04c5babd4bda73293ced93', NULL, NULL, NULL, NULL);

