<?
$mysql_host="localhost";
$mysql_user="root";
$mysql_pass="123456";
$mysql_dbname="bitcms";
?>