<?
$tpl_name="base";
$tpl_root="view/template/base";
$tpl_parent="view/template";
date_default_timezone_set('PRC');
$lan="cn";
