<?
require_once('Controller.php');
require_once('model/Block.php');
require_once 'model/Slider.php';
require_once 'model/BaseModel.php';
require_once 'controller/HomeController.php';
require_once('lib/DirUtil.php');

class AdminController extends Controller{
	
	public  $slider = null;
	public  $block = null;
	
	function __construct(){
		parent::__construct();
	}
	
	function index(){
		require('view/admin/index.php');
	}
	
	function logPage(){
		$dir = new DirUtil();
		$fileList = $dir->traverse("log");
		require('view/admin/log.php');
	}
	
	function backupPage(){
		$dir = new DirUtil();
		$fileList = $dir->traverse("backup");
		require('view/admin/backup.php');
	}
	
	function restorePage(){
		$dir = new DirUtil();
		$fileList = $dir->traverse("backup");
		require('view/admin/restore.php');
	}
	
	function backup(){
		include "config/config.php";
		include "config/site.php";
		$curTm = date("YmdHis",time());
		$model = new BaseModel();
		$model->db->backup($mysql_dbname,"backup/".$mysql_dbname."_".$curTm.".sql","data");
		$this->backupPage();
		
	}
	
	function restore(){
		
		$model = new BaseModel();
		
		$sqlfile = "backup/".$_POST["selbkfile"];
		$sqls = fread(fopen($sqlfile, "r"), filesize($sqlfile));
		$pieces = $model->db->split_sql($sqls);
		
		
		$result=mysql_query("show variables like 'have_innodb'");
     	$record = mysql_fetch_array($result);
		$have_innodb = $record["Value"];
				
		mysql_query("BEGIN");
		mysql_query("SET AUTOCOMMIT=0");
		foreach ($pieces as $sql){
			$ret = $model->db->exec($sql);
			if( $ret != 1){
				$fp = fopen("log/sys.log", "w");
				fwrite($fp, $sql." execute error!\r\n");
				fwrite($fp,"Trying rollback!\r\n");
				$result=mysql_query("show variables like 'have_innodb'");
     			$record = mysql_fetch_array($result);
				$have_innodb = $record["Value"];
				if(strcasecmp($have_innodb,"DISABLED") == 0){
					fwrite($fp,"Your engine does not surport rollback!\r\n");
				}else{
					mysql_query("ROLLBACK");
					fwrite($fp,"Rollback success!\r\n");
				}
				fclose($fp);
				echo "false";
				exit();
			}
		}
		mysql_query("COMMIT");
		echo "true";
		
	}
	
	function delFile($dir,$fileName){
		
		if( $fileName == "all"){
			$dirUtil = new DirUtil();
			$fileList = $dirUtil->traverse($dir);
			foreach ($fileList as $f){
				if(!unlink("$dir/$f")){
					echo "false";
					exit;
				}
			}
			echo "true";
		}else{
			if(unlink($fileName)){
				echo "true";
			}else{
				echo "false";
			}
		}
		
	}
	
	function delBackupFile(){
		$fileName = $_POST["filename"];
		$this->delFile("backup",$fileName);
	}
	
	function delLogFile(){
		$fileName = $_POST["filename"];
		$this->delFile("log",$fileName);
	}
	
	function publishPage(){
		
		require('view/admin/publish.php');
	}
	
	function publishStaticIndex(){
		
		include "config/site.php";
		
		$model = new BaseModel(); //reconnect to the msyql
		$m = $_POST["method"];
		$condition = "";
		if( $m == "0"){
			$condition="where sts='0' and (pub_tm='' or edit_tm > pub_tm)";
		}else{
			$condition="where sts !='-1'";
		}
		$contents = $model->getArrayList("content",$condition); 
		
		$model->release();
		
		foreach ($contents as $content){
			$fname = $tpl_root."/static/".$content['id'].".html";
			ob_start();
			$_GET["id"] = $content['id'];
			$home = new HomeController(); 
			$home->info();
			$content = ob_get_contents();
			ob_end_clean();
			$fp = fopen($fname, "w");
			fwrite($fp, $content);
			fclose($fp);
		}
		
		
		
		ob_start();
		$home = new HomeController(); 
		$home->indexDyn();  //php after render all mysql connections will be reset
		$content = ob_get_contents();
		ob_end_clean();
		$fp = fopen("$tpl_root/index.html", "w");
		fwrite($fp, $content);
		fclose($fp);
		
		echo "true";
	}
	
	function changePassWordPage(){
		require('view/admin/password.php');
	}
	
	function checkOriPassWord(){
		
		$model = new BaseModel();
		$cur_usr_nm = $_SESSION['loginuser']['usr_nm'];
		$ret = $model->db->isExists("users","usr_nm='".$cur_usr_nm."' and usr_pwd='".md5($_POST["ori_usr_pwd"])."'");
		if($ret){
			echo "true";
		}else{
			echo "false";
		}
	}
	
	function changePassWord(){
		
		$model = new BaseModel();
		$arr = array (
			'usr_pwd'
		);
		$_POST['usr_pwd'] = md5($_POST['usr_pwd']);
		$cur_usr_nm = $_SESSION['loginuser']['usr_nm'];
		$model->db->postUpdate("users",$arr,"usr_nm='".$cur_usr_nm."'");
		echo "true";
	}
}
/*end*/