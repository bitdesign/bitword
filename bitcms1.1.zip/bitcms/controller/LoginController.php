<?
//require_once('Controller.php');
require_once('model/User.php');
//class AdminController extends Controller{
class LoginController{
	
	private $user = null;
	
	function __construct(){
		$this->user = new User();
	}
	
	function index(){
		
		require('view/admin/login.php');
	}
	
	
	function logout(){
		session_start();
		$_SESSION=array();
		session_destroy();
		$this->index();
	}
	
	function login(){
		
		session_start();
		if(isset($_SESSION['loginuser']))
		{
			require('view/admin/index.php');
			return;
		}
				
		$usr_nm = $_POST["usr_nm"];
		$usr_pwd = $_POST["usr_pwd"];
		$user = $this->user->db->readRecord("users", "usr_nm='".mysql_real_escape_string($usr_nm)."' and usr_pwd='".md5($usr_pwd)."'");
		if (!empty($user)) {
			$_SESSION['loginuser'] = $user;
			echo "true";
		} else {
			echo "false";
		}
	}
	
	
}
/*end*/