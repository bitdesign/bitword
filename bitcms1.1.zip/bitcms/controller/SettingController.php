<?
require_once('Controller.php');

require_once('model/Siteparas.php');
require_once('model/Slider.php');

//class SettingController{
class SettingController extends Controller{
	
	private  $siteparas = null;
	
	function __construct(){
		parent::__construct();
		$this->siteparas = new Siteparas(); 
	}
	
	public function save(){
		$this->siteparas->save();
		$paras = $this->siteparas->getParas();
		$msg = "Save OK!";
		require('view/admin/setting.php');
	}

	public function saveSlider(){
		$slider = new Slider();
		$slider->save();
	}
	
	function settingPage(){
		$paras = $this->siteparas->getParas();
		require('view/admin/setting.php');
	}
	
}
/*end*/