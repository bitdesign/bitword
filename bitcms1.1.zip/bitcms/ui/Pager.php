<?
class Pager {
	
	public $pageNo=0;
	public $skipValue;
	public $totNo=0;
	public $perPageCnt=10;
	public $oldPerPageCnt=10; 
	public $tempName = "PagerView.php";
	
	public $table = "";
	public $db = "";    
	
	function getPageCnt() {
		$this->totNo = $this->db->getCount($this->table);
		return ceil($this->totNo*1.0/$this->perPageCnt);
	}
	
	function __construct($table,$db,$pageNo,$perPageCnt=10){
		$this->pageNo = $pageNo;
		$this->perPageCnt = $perPageCnt;
		$this->table = $table;
		$this->oldPerPageCnt = $perPageCnt;
		$this->db = $db;
	}
	
	function  getHtml(){
		 require("config/translate.php");
		 require($this->tempName);
	}
	
	function  getData(){
		$sql = $this->getSQL();
		return $this->db->queryForArray("($sql) tmp");
	}
	
	function  getSQL(){
		$opr = $this->skipValue;
		if( !empty($opr)){
			if(strcmp($opr,"first") == 0){
				$this->pageNo = 1;
			}else if(strcmp($opr,"pre") == 0){
				$this->pageNo -= 1;
			}else if(strcmp($opr,"next") == 0){
				$this->pageNo += 1;
			}else if(strcmp($opr,"last") == 0){
				$this->pageNo = $this->totNo;
			}else{
				$this->pageNo = $opr;
			}
		}
		$pageCnt = $this->pageNo;
		if( $pageCnt < 1) $pageCnt = 1;
		if( $this->pageNo> $pageCnt) $this->pageNo = $pageCnt;
		$beginIdx = $this->perPageCnt*($this->pageNo-1);
		$sql = "SELECT * FROM  $this->table limit $beginIdx,$this->perPageCnt";
		return $sql;
	}
}
