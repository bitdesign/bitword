<script language="JavaScript">
	$(function(){
		$("#navdiv a").click(function(){
			clickId = $(this).attr("id");
			var curNo = $("#skipValue").val();
			if(clickId=="first") clickId = 1;
			else if(clickId=="pre")  clickId = parseInt(curNo)-1;
			else if(clickId=="next") clickId = parseInt(curNo)+1;
			else if(clickId=="last") clickId = <?=$this->getPageCnt()?>;
			$("#skipValue").attr("value",clickId);
			$(this).parents("form").submit();
		});
		var aa = "#O"+<?=$this->perPageCnt?>;
		$(aa).attr("selected",'selected'); 
	});
	
	function doGo(){
		$("input[name='btngo']").click(); 
	}
</script>

<style>
	#navdiv a{
		text-decoration:none;
	}
</style>

<div id="navdiv" style="width:90%; height:30px;line-height:30px;">
	<input name='oldPerPageCnt' type='hidden' value='<?=$this->oldPerPageCnt?>'/>
	<div style="width:100px; height:30px; float:left;">[&nbsp;<?=$ttotal[$lan]?>&nbsp;<strong><?=$this->totNo?></strong>&nbsp;]</div>
    <div style="height:30px; float:right;">
    	<p style="display:block; float:left;">
    		<?
    		if( $this->pageNo == 1){
    			echo "&nbsp;$tfirst[$lan]&nbsp;&nbsp;$tpre[$lan]&nbsp;";
    		}else{
    			echo "<a href='#' id='first'>&nbsp;$tfirst[$lan]&nbsp;</a><a href='#' id='pre'>&nbsp;$tpre[$lan]&nbsp;</a>";
    		}
			
			$x = $this->getPageCnt();
			$startPageNo = floor($this->pageNo/10)*10;
			if($x == 0){
				echo "<a href='#' id='1'>&nbsp1&nbsp</a>";
			}else{
				$c = 1+$startPageNo;
				while($c <= $x){
					if($c > (10+$startPageNo)){
						break;
					} 
					if($c == $this->pageNo){
						echo "<a href='#' id='$c' style='text-decoration:none;'>&nbsp[$c]&nbsp</a>";
					}else{
						echo "<a href='#' id='$c'>&nbsp$c&nbsp</a>";
					}
					$c += 1;
				}
			}
			
			if($this->pageNo == $x){
				echo "&nbsp;$tnext[$lan]&nbsp;&nbsp;$tlast[$lan]&nbsp;";
			}else{
				echo "<a href='#' id='next'>&nbsp;$tnext[$lan]&nbsp;</a><a href='#' id='last'>&nbsp;$tlast[$lan]&nbsp;</a>";
			}
			?>
			
	        <span>&nbsp;&nbsp;<?=$tskip[$lan]?><input name='skipValue' id='skipValue' type='text' value="<?=$this->pageNo?>" onkeyup="this.value=this.value.replace(/\D/g,'1')" onafterpaste="this.value=this.value.replace(/\D/g,'1')" size="1"/></span> 
	        <input type='submit' name='btngo' value="GO"/>&nbsp;&nbsp;&nbsp;
	        <span><?=$tperpage[$lan]?></span>
	        <select name='perPageCnt' onchange="doGo();">
	        	<option id="O5">5</option>
				<option id="O10">10</option>
				<option id="O20">20</option>
				<option id="O50">50</option>
				<option id="O100">100</option>
			</select>
        </p>
        &nbsp;&nbsp;
    </div>
</div>