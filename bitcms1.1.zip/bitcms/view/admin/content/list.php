<!DOCTYPE html">
<html>
	
	<head>
		<title></title>
		<? include "_include.php"; ?>
		<script language="javascript" type="text/javascript">
			
			function del(id)
			{
				$.post("Content!del",{"id":id},
						function(data) {
							if(data == "true"){
								location.reload();
							}else{
								alert("<?=$tfailed[$lan]?>");
							}
						}
				);
			}
			
			function edit(id)
			{
				location.href="Content!editPage&id="+id;
			}
		</script>
		
		
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$tcontent[$lan]?></strong></div><a name="top"></a>
			<div class="pageContent">
				<form id="myform" method="post" action="Content!listPage">
				
					<div style="height:30px;line-height:30px;">
						<?=$tcategory[$lan]?>&nbsp;&nbsp;<input type="text" name="block_order" id="block_order"/>
						<?=$ttitle[$lan]?>&nbsp;&nbsp;<input type="text" name="block_name" id="block_name"/>
						<input type="submit" class="small_btn" value="<?=$tquery[$lan]?>" />
						<input type="button" class="small_btn" value="<?=$tadd[$lan]?>" onclick="edit('')"/>
					</div>
						
					<table class="myTable">
							<tr class="tbhead"><td style="padding-left:50px;"><?=$tcategory[$lan]?></td><td><?=$ttitle[$lan]?></td><td><?=$tkeyword[$lan]?></td><td><?=$tstatus[$lan]?></td><td><?=$tedittm[$lan]?></td><td><?=$publishtm[$lan]?></td><td><?=$toperation[$lan]?></td></tr>
							<?
								foreach ($arrayList as $row){
									echo "<tr><td style='padding-left:50px;'>".$row["block_name"]."</td><td>".$row["title"]."</td><td>".$row["keyword"]."</td><td>".$content_sts[$row["sts"]]."</td><td>".btime($row["edit_tm"])."</td><td>".btime($row["pub_tm"])."</td><td><a href='#' onclick=del(".$row["id"].")>$tdelete[$lan]</a>&nbsp;&nbsp;<a href='Content!editPage&id=".$row["id"]."'>$tmodify[$lan]</a></td></tr>";
								}
							?>
					</table>
					<? $pager->getHtml() ?>
				</form>
			</div>
		</div>
	</body>
	
</html>