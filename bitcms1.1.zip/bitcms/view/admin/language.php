<!DOCTYPE html">
<html>
	
	<head>
		<title></title>
		<? include "_include.php"; ?>
		
		<script language="javascript" type="text/javascript">
			
			$(function(){
				$("#<?=$lan?>").attr("checked",true);
			});
			
			function activeLan(){
				var lanNm = $("input[name='lanNm']:checked").val();
				$.post("Template!changeLan",{"lanNm":lanNm},
					function(data) {
						if(data == "true"){
							location.reload();
							alert("<?=$tsuccess[$lan]?>");
						}else{
							alert(data);
						}
					},"html"
				);				
			}
			
		</script>
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$tlanguage[$lan]?></strong></div>
			<div class="pageContent">
				<form  id="tplform">
						<div style="width:100%;padding:10px;">
								English&nbsp;<input type="radio" name="lanNm" id="en" value="en" style="vertical-align:middle;margin-right:30px;"/>
								中文&nbsp;<input type="radio" name="lanNm" id="cn" value="cn" style="vertical-align:middle;margin-right:30px;"/>
						</div>
						<div style="float:left;padding:10px;">
							<input type="button" class="mid_btn" onclick="activeLan();" value="<?=$tok[$lan]?>"/>		
						</div>
				</form>
			</div>
		</div>		
	</body>
	
</html>