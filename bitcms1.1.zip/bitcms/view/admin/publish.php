<!DOCTYPE html">
<html>
	
	<head>
		<title></title>
		
		<? include "_include.php"; ?>
		<script language="javascript" type="text/javascript">
			
			function doPublic(m){
				$.post("Admin!publishStaticIndex",{"method":m},
					function(data){
						if(data=="true"){
							alert("<?=$tsuccess[$lan]?>");
						}else alert(data);	
					},"html"
				);
			}
			
			function doPreview(){
				window.open("Home!indexDyn","_blank");
			}
		</script>
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$tpublish[$lan]?></strong></div>
			<div class="pageContent">
				<div style="float:left;padding:10px;width:100%;">
					
					<input type="button" class="large_btn" value="  <?=$tpubpreview[$lan]?>  " onclick="doPreview();"/>
					
					<input type="button" class="large_btn" value="  <?=$tincrepublish[$lan]?>  " onclick="doPublic(0);"/>
					
					<input type="button" class="large_btn" value="  <?=$ttopublish[$lan]?>  " onclick="doPublic(1);"/>
				</div>
			</div>
		</div>
	</body>
	
</html>