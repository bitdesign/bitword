<!DOCTYPE html">
<html>
	
	<head>
		<title></title>
		
		<? include "_include.php"; ?>
		<script type="text/javascript" src="js/ajaxfileupload.js"></script>
		
		<style>
			a img{
				padding:1px;
			}
			a.tpl img{
				border:3px solid #efefef;height:200px;width:274px;
			}
			a.tpl:hover img{border:3px solid #999;}
		</style>
		
		
		<script language="javascript" type="text/javascript">
			
			$(function(){
				$("#<?=$tpl_name?>").attr("checked",true);
			});
			
			function selectTpl(val){
				$('#'+val).attr("checked",true);
			}
			function activeTpl(){
				var tplNm = $("input[name='tplNm']:checked").val();
				$.post("Template!changeTpl",{"tplNm":tplNm},
					function(data) {
						if(data == "true"){
							location.reload();
							alert("<?=$tsuccess[$lan]?>");
						}else{
							alert(data);
						}
					},"html"
				);				
			}
			
			function doUpload()
			{
				var localFilename = $("#tpl").val();
				var idx = localFilename.lastIndexOf('\\');
				if(idx<0){
					idx = localFilename.lastIndexOf('/');
				}
				filename = localFilename.substring(idx+1);
				
				$("#zipfile").val(filename);
				
				$.ajaxFileUpload({
					url:'File!upload',
					data:{'name':'tpl','path':'view/template'},
					type:'POST',
					secureuri:false,
					fileElementId:'tpl',
					dataType: 'json',
					success: function (data, status){
						if(data.msg == "true"){
							$.post("Template!unzip",{"zipfile":filename},
									function(data) {
										if(data == "true"){
											location.href = location.href;
											alert("<?=$tsuccess[$lan]?>");
											
										}else{
											alert(data);
										}
									},"html"
							);
						}
						else{
							alert(data.msg);
							return;
						}
					},
					error: function (data, status, e){
						alert(e);
					}
				});
			}
		</script>
	</head>
	
	<body>
		<div class="iframeBody">
			<div class="pageName"><strong><?=$ttheme[$lan]?></strong></div>
			<div class="pageContent">
				<form action="Template!unzip" method="POST" id="myform">
					<table class="myTable">
						<tr>
							<td>
								<input type="hidden" id="zipfile" name="zipfile" value=""/>
								<?=$tupload[$lan]?>&nbsp;&nbsp;<input type="file" name="tpl" id="tpl"/>
								<input type="button" class="mid_btn" onclick="doUpload();" value="<?=$tupload[$lan]?>"/>
								<input type="button" class="mid_btn" onclick="activeTpl();" value="<?=$tactive[$lan]?>"/>
							</td>
						</tr>
					</table>
				</form>	
				
				<form  id="tplform">
					<?foreach ($tplList as $tpl){?>
						<div style="float:left;padding:10px;">
							<div>
								<a class="tpl" onclick="selectTpl('<?=$tpl?>')"><img src="<?=$tpl_parent.'/'.$tpl?>/preview.jpg"/></a>
							</div>
							<div style="text-align:center;">
								<?=$tpl?>&nbsp;<input type="radio" name="tplNm" id="<?=$tpl?>" value="<?=$tpl?>" style="vertical-align:middle;"/>
							</div>
						</div>					
					<?}?>	
				</form>		
			</div>
		</div>	
	</body>
	
</html>