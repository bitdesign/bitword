<div class="footer">
	<div class="copyright">
		Powered by BitCMS_V1 &copy; 2013 <br/> 
		Copyright &copy; 2013 BITESHEJI All Rights Reserved <br/>
		<!--<iframe id="stscodeFrame" frameborder="0" height="50" width="100"></iframe>-->
		<?=$accstat?>
	</div>     
</div>
