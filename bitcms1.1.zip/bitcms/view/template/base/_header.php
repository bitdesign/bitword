<div class="logo">
	<img src="<?=$logo?>"/>			
</div>	
<div class="menu">
	<ul>
    	<li><a href="<?=$webroot?>/Home!index">首页</a></li>
    	<li><a href="https://github.com/bitdesign/">开源项目</a></li>
    	<li><a href="<?=$webroot?>/Admin!index"">管理后台</a></li>
    </ul>
</div>