<!DOCTYPE html">
<html>
	<head>
		<?include "_include.php";?>
	</head>
	
	<body>
		<div class="all">
			
			<?include "_header.php";?>
			
			<div class="content">
					<div class="content_left">
						<?
						foreach (tarray($blocks[1]) as $block){
						?>
												
				                <div class="ctx">
				                		<?foreach ($block["contents"] as $content){?>
					                		<p><a href="<?=$tpl_root?>/static/<?=$content['id']?>.html"><?=$content["title"]?></a></p>
					                		<span class="ctxbody"><?=$content["content"]?>
					                		</span>
				                		<?}?>
				                </div>
						<?
						}
						?>
					</div>
					<div class="content_right">
						
						<?
						foreach ( tarray($blocks[9]) as $block){
						?>
							<div class="box box1">
								<div class="title">
			                		<strong><?=$block["block_name"]?></strong>
				                </div>
				                <div class="ctx">
				                	<ul>
				                		<?foreach ($block["contents"] as $content){?>
					                		<li name=info>
					                		<?
					                			echo $content["title"].":".$content["content"];
					                		?>
					                		</li>
				                		<?}?>
					                </ul>
				                </div>
							</div>
						<?
						}
						?>
						
						
						<?
						foreach ( tarray($blocks[8]) as $block){
						?>
							<div class="box box1">
								<div class="title">
			                		<strong><?=$block["block_name"]?></strong>
				                </div>
				                <div class="ctx">
				                	<ul>
				                		<?foreach ($block["contents"] as $content){?>
					                		<li name=info>
					                		<a href="<?=$tpl_root?>/static/<?=$content['id']?>.html"><?=$content["title"]?></a>
					                		</li>
				                		<?}?>
					                </ul>
				                </div>
							</div>
						<?
						}
						?>
					</div>
			</div>
			<?include "_footer.php";?>
			
		</div>
	</body>
	
</html>