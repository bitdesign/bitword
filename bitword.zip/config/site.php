<?
date_default_timezone_set('PRC');
include "config.php";
$logo='logo.png';
$name='BitWord';
$keywords='BitWord';
$description='BitWord';
$tpl_root='view/template/default';
$tpl_name='default';
$accstat='';
$notice='';
$headimg='';
$homemaxnum='50';
$newmaxnum='10';
$topmaxnum='';
$commentswitch='1';
$commentdspnum='10';
