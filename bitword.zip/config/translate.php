<?

require("config/config.php") ;
require("config/translate/$lan.php") ;

$content_sts = array("-1" => "$tdraft","1" => "$tpublished");
