<?

require("config/config.php");

$noteSelFile = "Please select a copy data";
$tconsole = "Console";
$tcontents = "Content";
$tcontentlist = "Content list";
$tcontentedit = "Content edit";
$treplies = "Replies";
$tblock = "Category";

$tsetting = "Setting";
$tdoset = "Setting";
$ttheme = "Theme";
$tlanguage = "Language";
$tother = "Other";
$tdatamng = "Backup";
$tbackup = "Backup";
$tclear = "Clearall";
$trestore = "Restore";
$tdelete = "Delete";


$tpassword = "Password";
$tsuccess = "Success";
$tfailed = "Failed";
$tedit = "Edit";
$tcategory = "Category";
$tselect = "Select";
$ttitle = "Title";
$tkeyword = "Site Keyword";
$tstatus = "Status";
$tpublished = "Published";
$ttopublished = "Publish";
$tdraft = "Draft";
$ttext = "Content";
$tsave = "Save";
$tclose = "Close";
$tquery = "Query";
$tadd = "Add";
$tuser = "Author";
$taddarticle = "New article";

$tall = "All";

$toperation = "Operation";

$tbatchdelete = "Batch Delete";

$tinputtm = "Input Time";
$tedittm = "Last Edit Time";
$publishtm = "Publish Time";
$publishok = "Publish success" ;
$torecommend = "Recommend" ;
$trecommend = "Recommend success" ;
$visits = "Visits";
$topnum = "Top";
$replyctx = "Reply";
$oritile = "Article Title";
$oriid = "Article ID";
$replyid = "Reply ID";
$tfirst = "First";
$tlast = "Last";
$tpre = "Pre";
$tnext = "Next";
$tskip = "Skip";
$tperpage = "How many records do you want to show in one page";
$ttotal = "Total";
$timage = "Image";
$tbrowse = "Browse";
$tupload = "Upload";
$tuploadsuc = "Upload success";
$tuploadfail = "Upload failed";
$torder = "Order";
$tname = "Name";
$tposition = "Position";
$tlink = "Link";
$tincrepublish = "Publish New";
$ttopublish = "Publish All";
$tpubpreview = "Publish preview";
$tsitename = "Site Name";
$tdescription = "Site Description";
$twebroot = "Webroot";
$taccstat = "Access statistics code";
$thomemaxnum = "How many records do you want to show in homepage";
$tnewmaxnum = "How many newest records do you want to show in homepage's rightpart";
$ttopmaxnum = "Top visits records";
$tcommentswitch = "Comment function";
$tcommentdspnum = "How many comments displayed in one page";
$tactive = "Active";
$tok = "OK";
$tpwdtips = "Incorrect";
$tdiffpwdtips = "Do not match";
$tpwdori = "Passwrod";
$tpwdnew = "New password";
$tconfirmpwd = "Confirm";
$tconfirm = "Confirm";
$thomepage = "Homepage";
$tlogout = "Logout";
$tlogerr = "User name or password is wrong";
$trestoretips = "Restore failed,please check the syslog";
$ttitletips = "Please input title";
$ton = "On";
$toff = "Off";
$tblocktips = "Please input block name";
$tcattips = "Please create a category first";
$tnoseltips = "Pleaseinputtitle";
$tbasedelerror = "Please do not delete the default theme!";
$tuploadtips = "Click picture to upload another one";

$tnotice = "Notice";

$tpleaselogin = "Please signin";
$tlogin = "Signin";
$tremember = "Rememberme";


