<?

$phpversion1 = "您的PHP版本为";
$phpversion2 = "但是安装bitword最低要求5.1.2,请和您的服务提供商联系。";

$phpatt1 = "您的服务器限制附件大小为";
$phpatt2 = "但是安装bitword最低要求1M,请和您的服务提供商联系。";

$spacechk1 = "您的服务器可用空间为";
$spacechk2 = "但是安装bitword需要10M空间,请和您的服务提供商联系。";

$begininst = "现在就开始!";

$formdb = "请在下方填写您的数据库连接信息";

$formhost = "数据库主机";
$hosttip = "如果填写localhost无法正常安装,请和您的服务提供商联系。";

$formdbname= "数据库名";
$dbtip = "将BitWORD安装到哪个数据库?";

$formuname = "用户名";
$dbnametip = "您的MySQL用户名";

$formupwd = "密码";
$dbpwdtip = "及以上用户名的对应密码";


$formacctip = "请设置您的登录账号和密码";
$formacc= "账号";
$formaccpwd= "密码";
$accpwdtip = "提示:您的密码至少要包含6个字符,而且最好是数字,字母,特殊字符混合使用";

$inst = "安装BitWORD";



$plsuname = "请输入用户名";
$plsupwd = "请输入密码";
$plsupwdlen = "密码不能少于{0}个字符";
$plshost = "请输入数据库主机地址";
$plsdbname = "请输入数据库名";
$plsdbuname = "请输入数据库用户名";
$plsdbupwd = "请输入数据库密码";



$errtip = "出错啦...";
$suctip ="BitWORD安装完成。您已经可以使用刚刚设定的账号和密码登录了。";

$prestep = "返回上一步";
$loginnow = "立即登录";


