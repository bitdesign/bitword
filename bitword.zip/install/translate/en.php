<?

$phpversion1 = "Your PHP version is ";
$phpversion2 = " but the minimum requirements for the installation is 5.1.2 , please contact your service provider.";

$phpatt1 = "Your server is limited to the size of the attachment ";
$phpatt2 = " but the minimum requirements for the installation is ,please contact your service provider.";

$spacechk1 = "Your server's free space is ";
$spacechk2 = "but installing bitword requires 10M space,please contact your service provider.";

$begininst = "Let's go !";

$formdb = "Please fill in your database connection information below";

$formhost = "Database host";
$hosttip = "If you fill out the 'localhost' can not work, please contact your service provider.";

$formdbname= "Database name";
$dbtip = "Which database do you want to installe  bitword to?";

$formuname = "Username";
$dbnametip = "Your MySQL username";

$formupwd = "Password";
$dbpwdtip = "and the corresponding password for the above user name";


$formacctip = "Please set your login ID and password";
$formacc= "Login ID";
$formaccpwd= "Password";
$accpwdtip = "Your password should be at least 6 characters";

$inst = "Install bitword";



$plsuname = "Please enter a user name";
$plsupwd = "Please enter a password";
$plsupwdlen = "Password cannot be less than {0} characters";
$plshost = "Please enter the database host address";
$plsdbname = "Please enter the database name";
$plsdbuname = "Please enter the database user name";
$plsdbupwd = "Please enter the database password";



$errtip = "Something is wrong...";
$suctip ="bitword installed success. You can log in now.";

$prestep = "Go back";
$loginnow = "Immediately log in";


