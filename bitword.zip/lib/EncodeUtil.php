<?php
class EncodeUtil {

	
}