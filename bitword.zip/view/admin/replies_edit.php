
<? include "config/translate.php"; ?>
<div class="modal-body">
	<?=$obj["rep_ctx"]?>
</div>
<div class="modal-footer">
	<button type="button" class="btn btn-default" onclick="doClose()"><?=$tclose?></button>
</div>
