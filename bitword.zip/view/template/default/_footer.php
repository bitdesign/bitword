<div class="footer">
<?=stripslashes(base64_decode($accstat))?>&copy; BIT1010 2014 All Rights Reserved .  Powered by <a href="http://www.bit1010.com">BITWORD v1.0</a>
</div>
