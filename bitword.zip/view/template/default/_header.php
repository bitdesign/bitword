<div class="header">
    <div class="logo">
        <a class="logo" href="<?=$webroot?>/index.html"><img src="<?=$webroot.'/upload/'.$logo ?>" /></a>
    </div>
    <div class="nav" >
        <a href="<?=$webroot?>/index.html">Homepage</a>
        <a href="<?=$webroot?>/content!listPage" target="_blank">Console</a>
    </div>
</div>





