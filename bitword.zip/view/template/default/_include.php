<title><?=$name?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="<?=$keywords?>" />
<meta name="Description" content="<?=$description?>" />

<link href="view/public/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="screen" />
<link href="<?=$webroot.'/'.$tpl_root.'/css/simple.css' ?>" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript" src="view/public/js/jquery.js"></script>
<script type="text/javascript" src="view/public/js/jquery.form.js"></script>
<script type="text/javascript" src="view/public/js/jquery.lazyload.min.js"></script>
